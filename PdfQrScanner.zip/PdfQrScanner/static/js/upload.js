document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const progressContainer = document.getElementById('progressContainer');
    const progressBar = progressContainer.querySelector('.progress-bar');
    const resultsContainer = document.getElementById('results');

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight drop zone when dragging over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, unhighlight, false);
    });

    // Handle dropped files
    dropZone.addEventListener('drop', handleDrop, false);
    fileInput.addEventListener('change', handleFiles, false);

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function highlight(e) {
        dropZone.classList.add('highlight');
    }

    function unhighlight(e) {
        dropZone.classList.remove('highlight');
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles({ target: { files: files } });
    }

    function handleFiles(e) {
        const files = [...e.target.files];
        
        // Validate files
        const invalidFiles = files.filter(file => !file.name.toLowerCase().endsWith('.pdf'));
        if (invalidFiles.length > 0) {
            showError('Please upload PDF files only');
            return;
        }

        uploadFiles(files);
    }

    function uploadFiles(files) {
        progressContainer.classList.remove('d-none');
        progressBar.style.width = '0%';
        resultsContainer.innerHTML = '';

        const formData = new FormData();
        files.forEach(file => {
            formData.append('files[]', file);
        });

        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(results => {
            progressBar.style.width = '100%';
            setTimeout(() => progressContainer.classList.add('d-none'), 1000);
            displayResults(results);
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Upload failed: ' + error.message);
            progressContainer.classList.add('d-none');
        });
    }

    function displayResults(results) {
        resultsContainer.innerHTML = '';
        
        results.forEach(result => {
            const resultDiv = document.createElement('div');
            resultDiv.className = `alert ${result.status === 'success' ? 'alert-success' : 'alert-danger'} mb-3`;
            
            const content = result.status === 'success'
                ? `<strong>${result.filename}</strong><br>QR Code Content: ${result.qr_data}`
                : `<strong>${result.filename}</strong><br>Error: ${result.error}`;
            
            resultDiv.innerHTML = content;
            resultsContainer.appendChild(resultDiv);
        });
    }

    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger';
        errorDiv.textContent = message;
        resultsContainer.innerHTML = '';
        resultsContainer.appendChild(errorDiv);
    }
});
